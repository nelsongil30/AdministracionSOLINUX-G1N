#ifndef RTW_VERSION_H
	#define RTW_VERSION_H
	#define RTW_VERSION "rtw_r19776.20161024"
#endif /* RTW_VERSION_H */
