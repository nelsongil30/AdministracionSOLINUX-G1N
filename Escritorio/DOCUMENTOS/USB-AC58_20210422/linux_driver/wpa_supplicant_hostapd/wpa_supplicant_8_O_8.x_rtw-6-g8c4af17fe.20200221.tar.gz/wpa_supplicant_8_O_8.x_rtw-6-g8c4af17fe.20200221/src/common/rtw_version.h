#ifndef RTW_VERSION_H
	#define RTW_VERSION_H
	#define RTW_VERSION "rtw-6-g8c4af17fe.20200221"
#endif /* RTW_VERSION_H */
